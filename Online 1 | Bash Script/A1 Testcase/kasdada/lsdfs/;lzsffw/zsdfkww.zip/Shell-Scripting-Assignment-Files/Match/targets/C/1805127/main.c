#include <stdio.h>

int main()
{
	int n, a;
	scanf("%d", &n);
	
	while(n--)
	{
		scanf("%d", &a);
		printf("YES\n");
	}
}
